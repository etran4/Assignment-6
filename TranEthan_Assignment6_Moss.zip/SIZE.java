package A6;

public enum SIZE 
{
	SMALL, MEDIUM, LARGE
}
