package A6;

public class Coffee extends Beverage 
{
	private boolean extraSyrup;
	private boolean extraShot;
	
	public Coffee(String bevName, SIZE size, boolean extraShot, boolean extraSyrup) 
	{
        super(bevName, TYPE.COFFEE, size);
        this.extraShot = extraShot;
        this.extraSyrup = extraSyrup;
	}
    public double calcPrice() 
    {
        return BASE_PRICE + (getSize().ordinal() * SIZE_PRICE) + (extraSyrup ? 0.50 : 0) + (extraShot ? 0.50 : 0);
    }
	public boolean getExtraShot() 
	{
		return extraShot; //Returns extra shot
	}
	public void setExtraShot(boolean extraShot) 
	{
		this.extraShot = extraShot;
	}
	public boolean getExtraSyrup()
	{
		return extraSyrup; //Returns extra syrup
	}
	public void setExtraSyrup(boolean extraSyrup) 
	{
		this.extraSyrup = extraSyrup;
	}	
	public String toString() 
	{
		return super.toString() + Boolean.toString(extraSyrup) + Boolean.toString(extraShot);
	}
	public boolean equals(Coffee comparing) 
	{
		return super.equals(comparing) && comparing.getExtraShot() ==  comparing.getExtraSyrup() == extraSyrup;
	}
}