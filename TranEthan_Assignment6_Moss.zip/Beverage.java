package A6;

public abstract class Beverage 
{
	private String bevName;
	private TYPE type;
	private SIZE size;
	final double BASE_PRICE = 2;
	final double SIZE_PRICE = 1;
	
	public boolean equals(Beverage comparing) 
	{
		return comparing.bevName == bevName && comparing.type == type && comparing.size == size;
	}

	public Beverage(String bevName, TYPE type, SIZE size) 
	{
		this.bevName = bevName;
		this.type = type;
		this.size = size;
	}
	public void getBevName(String bevName) 
	{
		this.bevName = bevName;
	}
	public TYPE getType() 
	{
		return type;
	}
	public void setType(TYPE type) 
	{
		this.type = type;
	}
	public SIZE getSize() 
	{
		return size;
	}
	public void setSize(SIZE size) 
	{
		this.size = size;
	}
		public double getBasePrice() 
	{
		return BASE_PRICE;
	}	
	public abstract double calcPrice();	
	public String getBevName() 
	{
		return bevName;
	}
	public String toString() 
	{
		return "" + bevName + type + size + calcPrice() ;
	}
}