package A6;
import java.util.ArrayList;

public class Order implements OrderInterface, Comparable<Object>
{
    private DAY orderDay;
    private int orderTime;
	private int orderNo;
    private ArrayList<Beverage> beverages = new ArrayList<Beverage>();
	private Customer customer;

    public Order(int orderNo, int orderTime, DAY orderDay, Customer customer) 
    {
    	this.customer = customer;
    	this.orderDay = orderDay;
        this.orderTime = orderTime;
        this.orderNo = orderNo;
    }
    public Order(int orderNo, DAY orderDay, Customer customer) 
    {
    	this.customer = customer;
    	this.orderDay = orderDay;
        this.orderNo = orderNo;
    }
    public int getOrderNo() 
    {
		return orderNo;
	}
	public void setOrderNo(int orderNo) 
	{
		this.orderNo = orderNo;
	}
	public int getOrderTime() 
	{
		return orderTime;
	}
	public void setOrderTime(int orderTime) 
	{
		this.orderTime = orderTime;
	}
	public DAY getOrderDay() 
	{
		return orderDay;
	}
	public void setOrderDay(DAY orderDay) 
	{
		this.orderDay = orderDay;
	}
	public Customer getCustomer() 
	{
		return new Customer(customer);
	}
	public void setCustomer(Customer customer) 
	{
		this.customer = customer;
	}
    public boolean isWeekend() 
    {
        return orderDay == DAY.SUNDAY || orderDay == DAY.SATURDAY;
    }
    public Beverage getBeverage(int index) 
    {
        return beverages.get(index);
    }
    
    public void addNewBeverage(String bevName, SIZE size, boolean hasExtraShot, boolean hasExtraSyrup) 
    {
        Coffee coffee = new Coffee(bevName, size, hasExtraShot, hasExtraSyrup);
        beverages.add(coffee);
    }
    public void addNewBeverage(String bevName, SIZE size, int numOfFruits, boolean addProtein) 
    {
        Smoothie smoothie = new Smoothie(bevName, size, numOfFruits, addProtein);
        beverages.add(smoothie);
    }
    public void addNewBeverage(String bevName, SIZE size) 
    {
        Alcohol alcohol = new Alcohol(bevName, size, isWeekend());
        beverages.add(alcohol);
    }

    public int getRand() //Generates random orderNo
    {
        return (int) Math.floor(Math.random() * (90000 - 10000 + 1) + 10000);
    }

    public double calcOrderTotal() //Calculates then returns total amount for the order
    {
        double total = 0;
       
        for (Beverage beverage : beverages) 
        {
            total += beverage.calcPrice();
        }
        return total;
    }
    
    public int findNumOfBeveType(TYPE type)
	{
        int count = 0;
       
        for (Beverage beverage : beverages) 
        {
            if (beverage.getType() == type) 
            {
                count++;
            }
        }
        return count;
    }
	public int getTotalItems() 
	{
	    return beverages.size();
	}

    public int compareTo(Object comparing)
    {
        Order other = (Order) comparing;

        if (other.orderNo == orderNo) 
        {
            return 0;
        }
        else if (other.orderNo > orderNo) 
        {
            return 1;
        } 
        else 
        {
            return -1;
        }
    }

    public String toString() 
    {
        String returning =  "" + getOrderNo() + calcOrderTotal() + customer;
        for (Beverage beverage : beverages) 
        {
            returning += beverage;
        }
        return returning;
    }
}