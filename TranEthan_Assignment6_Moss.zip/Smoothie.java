package A6;

public class Smoothie extends Beverage 
{
	private boolean addProtein;
	private int numOfFruits;

	public Smoothie(String bevName, SIZE size, int numOfFruits, boolean addProtein) 
	{
        super(bevName, TYPE.SMOOTHIE, size);
        this.addProtein = addProtein;
        this.numOfFruits = numOfFruits;
	}
    public double calcPrice() 
    {
        return BASE_PRICE + (getSize().ordinal() * SIZE_PRICE) + (addProtein ? 1.50 : 0) + (numOfFruits * 0.50);
    }
	public boolean getAddProtein()
	{
		return addProtein;
	}
	public void setAddProtein(boolean addProtein) 
	{
		this.addProtein = addProtein;
	}
	public int getNumOfFruits() 
	{
		return numOfFruits;
	}
	public void setNumOfFruits (int numOfFruits)
	{
		this.numOfFruits = numOfFruits;
	}
    public String toString()
    {
		return super.toString() + Boolean.toString(addProtein) + numOfFruits ;
	}
	public boolean equals(Smoothie other) 
	{
        return super.equals(other) && numOfFruits == other.numOfFruits && other.addProtein == addProtein;
	}
}