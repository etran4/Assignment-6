package A6;
import java.util.ArrayList;

public class BevShop implements BevShopInterface
{
    private int numOfAlcoholicDrink;
	private ArrayList<Order> orders = new ArrayList<Order>();

	public boolean validAge(int age) 
    {
        return age > getMinAgeForAlcohol(); //Sees if the person is old enough for alcohol
    }
	public int getMaxOrderForAlcohol() 
	{
	    return BevShopInterface.MAX_ORDER_FOR_ALCOHOL; //Returns alcohol order limit
	}
    public int getMinAgeForAlcohol() 
    {
        return BevShopInterface.MIN_AGE_FOR_ALCOHOL; // Returns the minimum age for alcohol
    }
	public int getNumOfAlcoholDrink() 
    {
		return numOfAlcoholicDrink; //Returns number of alcoholic drinks
	}
	public boolean validTime(int time) 
	{
	    return time >= BevShopInterface.MIN_TIME && time <= BevShopInterface.MAX_TIME; //Sees if the time is in range for open
	}
    public boolean eligibleForMore() 
    {
        return numOfAlcoholicDrink < BevShopInterface.MAX_ORDER_FOR_ALCOHOL; //Sees if the amount of drinks has reached the max
    }
    public boolean isMaxFruit(int fruit) 
    {
        return BevShopInterface.MAX_FRUIT != fruit; //Sees if max amount of fruit has been reached
    }

    public void startNewOrder(int time, DAY day, String customerName, int customerAge) //Makes new order
    {
        orders.add(new Order(orders.size(), time, day, new Customer(customerName, customerAge)));
        numOfAlcoholicDrink = 0;
    }

    public void processSmoothieOrder(String name, SIZE size, int numOfFruits, boolean addProtein) //Process of smoothie order
    {
        getCurrentOrder().addNewBeverage(name, size, numOfFruits, addProtein);
    }
    public void processAlcoholOrder(String name, SIZE size) //Process of alcohol order
    {
        getCurrentOrder().addNewBeverage(name, size);
        numOfAlcoholicDrink++;
    }
    public void processCoffeeOrder(String name, SIZE size, boolean extraShot, boolean extraSyrup) //Process of the current coffee order
    {
        getCurrentOrder().addNewBeverage(name, size, extraShot, extraSyrup); 
    }

    public int findOrder(int orderNo) //finds order through number searching
    {      
    	for (int x = 0; x < orders.size(); x++) 
    	{
            if (orders.get(x).getOrderNo() == orderNo) 
            {
                return x;
            }
        }
        return -1;
    }

    public double totalOrderPrice(int orderNo) 
    {
        return orders.get(orderNo).calcOrderTotal();
    }
    public int totalNumOfMonthlyOrders() 
	{
	    return orders.size();
	}
	public double totalMonthlySale() //Calculates total monthly sale
	{
        double total = 0;

        for (Order order: orders) 
        {
            total += order.calcOrderTotal();
        }
        return total;
	}
	public Order getCurrentOrder() 
    {
        return getOrderAtIndex(orders.size() - 1);
    }
	public Order getOrderAtIndex(int index) 
	{
	    return orders.get(index);
	}
    public void sortOrders() 
    {
        for (int x = 0; x < orders.size(); x++) 
        {
            Order order = orders.get(x);
            int maxIndex = x + 1;
            int maxOrderNo = orders.get(maxIndex).getOrderNo();

            for (int y = maxIndex; x < orders.size(); x++) 
            {
                Order otherOrder = orders.get(y);
                int orderNo = otherOrder.getOrderNo();
                		
                if (orderNo > maxOrderNo) 
                {
                    maxIndex = y;
                    maxOrderNo = orderNo;
                }
            }
            if (order.getOrderNo() > maxOrderNo) 
            {
                orders.set(x, orders.get(maxIndex));
                orders.set(maxIndex, order);
            }
        }
    }
    public String toString() 
    {
        String returning = "" + totalMonthlySale();
        
        for (Order order: orders) 
        {
            returning += order;
        }
        return returning;
    }
}