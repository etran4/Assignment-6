package A6;

public class Alcohol extends Beverage 
{
	private boolean weekend;

	public Alcohol(String bevName, SIZE size, boolean weekend)
	{
        super(bevName, TYPE.ALCOHOL, size);
        this.weekend = weekend;
	}
    public double calcPrice() 
    {
        return BASE_PRICE + (getSize().ordinal() * SIZE_PRICE) + (weekend ? 0.60 : 0);
    }
	public boolean getWeekend() 
	{
		return weekend;
	}
	public void setWeekend(boolean weekend)
	{
		this.weekend = weekend;
	}
	public String toString() 
	{
		return super.toString() + Boolean.toString(weekend);
	}
	public boolean equals(Alcohol comparing) 
	{
		return super.equals(comparing) && comparing.weekend ==  weekend;
	}
}