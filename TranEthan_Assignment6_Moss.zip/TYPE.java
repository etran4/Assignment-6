package A6;

public enum TYPE 
{
	COFFEE, SMOOTHIE, ALCOHOL
}
